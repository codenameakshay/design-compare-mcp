"""Per-dimension comparison metrics."""
